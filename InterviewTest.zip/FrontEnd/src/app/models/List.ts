export interface IList {
    name: string;
    power : string;
    stats : any;
}